package com.facebook;

public class Constants {
    public static String FACEBOOK_APP_ID = "782553829921952";
    public static String FACEBOOK_APP_SECRET = "7237550f7d4b6207b8561bcd76c2e90e";
    public static String FACEBOOK_REDIRECT_URL = "https://localhost:8080/AccessFacebook/login-facebook";
    public static String FACEBOOK_LINK_GET_TOKEN = "https://graph.facebook.com/oauth/access_token?client_id=%s&client_secret=%s&redirect_uri=%s&code=%s";
}
